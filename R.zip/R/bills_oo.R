#' raw bi-monthly bill information from 2018 survey
#'
#'
#' @format vector with 759 elements:
#' \describe{
#'   \item{q9_1}{bill in euros}
#' }
#' @source \url{}
"bills_oo"
