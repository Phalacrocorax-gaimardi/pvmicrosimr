#' raw bi-monthly bill information from 2018 survey
#'
#'
#' @format A data frame with 1208 rows and 1 variables:
#' \describe{
#'   \item{q9_1}{bill in euros}
#' }
#' @source \url{https://www.seai.ie/data-and-insights/seai-statistics/key-statistics/prices/}
"bills"
