#' questions from reduced CER survey
#'
#'
#' @format A data frame with 12 rows and 2 variables:
#' \describe{
#'   \item{code}{code}
#'   \item{question}{question}
#' }
#' @source CER
"cer_questions"
