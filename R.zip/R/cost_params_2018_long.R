#' pricing and cost estimates 2018
#'
#' useful questions from CER dataset
#'
#' @format A data frame with 17 rows and 2 variables:
#' \describe{
#'   \item{parameter}{parameter}
#'   \item{value}{value. Costs in euros.}
#' }
#' @source multiple
"cost_params_2018_long"
